(*************************************************************
 *                                                           *
 *       Cryptographic protocol verifier                     *
 *                                                           *
 *       Bruno Blanchet and David Cadé                       *
 *                                                           *
 *       Copyright (C) ENS, CNRS, INRIA, 2005-2022           *
 *                                                           *
 *************************************************************)

(*

    Copyright ENS, CNRS, INRIA 
    contributors: Bruno Blanchet, Bruno.Blanchet@inria.fr
                  David Cadé

This software is a computer program whose purpose is to verify 
cryptographic protocols in the computational model.

This software is governed by the CeCILL-B license under French law and
abiding by the rules of distribution of free software.  You can  use, 
modify and/ or redistribute the software under the terms of the CeCILL-B
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-B license and that you accept its terms.

*)
open Lexing

let internal_error mess =
  print_string ("Internal error: " ^ mess ^ "\nPlease report bug to Bruno.Blanchet@inria.fr, including input file and output\n");
  exit 3

(* extent, for error messages *)

type extent = Lexing.position * Lexing.position

exception Error of string * extent

let dummy_ext = (Lexing.dummy_pos, Lexing.dummy_pos)

let raise_error s ext =
  raise (Error(s,ext))

let raise_user_error s =
  raise (Error(s,dummy_ext))

let ovf_dim = "Overflow in exponent while computing a dimension"
    
let add_check_overflow msg ext n1 n2 =
  if (n2 > 0 && n1 > max_int-n2) || (n2 < 0 && n1 < min_int-n2) then
    raise_error msg ext;
  n1 + n2

let sub_check_overflow msg ext n1 n2 =
  if (n2 > 0 && n1 < min_int + n2) || (n2 < 0 && n1 > max_int+n2) then
    raise_error msg ext;
  n1 - n2

let mul_check_overflow msg ext n1 n2 =
  if (n1 > 0 && n2 > 0 && n1 > max_int/n2) ||
     (n1 < 0 && n2 > 0 && n1 < min_int/n2) ||
     (n1 > 0 && n2 < 0 && n2 < min_int/n1) ||
     (n1 < 0 && n2 < 0 && n1 < max_int/n2)
  then
    raise_error msg ext;
  n1 * n2
    
let merge_ext (p1,_) (_,p2) = (p1,p2)

let extent lexbuf = 
  (Lexing.lexeme_start_p lexbuf,
   Lexing.lexeme_end_p lexbuf)

let set_start lexbuf (loc_start, _) =
  if loc_start != Lexing.dummy_pos then
    begin
      lexbuf.lex_abs_pos <- loc_start.pos_cnum;
      lexbuf.lex_start_p <- loc_start;
      lexbuf.lex_curr_p <- loc_start
    end
      
let parse_extent () =
  (Parsing.symbol_start_pos(),
   Parsing.symbol_end_pos())

let display_error mess (loc_start, loc_end) =
  if loc_start.pos_cnum = -1 then
    Printf.printf "Error: %s\n" mess
  else
    Printf.printf "Character %d - character %d:\nError: %s\n"
      loc_start.pos_cnum
      loc_end.pos_cnum
      mess

let line_position (loc_start, loc_end) =
  let ch_start = loc_start.pos_cnum - loc_start.pos_bol +1 in
  let ch_end = loc_end.pos_cnum - loc_end.pos_bol+1 in
  if loc_start.pos_lnum = loc_end.pos_lnum then
    if ch_start = ch_end then
      Printf.sprintf "line %d, character %d"
	loc_start.pos_lnum ch_start
    else
      Printf.sprintf "line %d, characters %d-%d"
	loc_start.pos_lnum ch_start ch_end
  else
    Printf.sprintf "line %d, character %d - line %d, character %d"
      loc_start.pos_lnum ch_start
      loc_end.pos_lnum ch_end
      
let in_file_position (def_start,_) ((loc_start, _) as extent) =
  if loc_start.pos_cnum = -1 then
    "<unknown>"
  else
    if loc_start.pos_fname = def_start.pos_fname then
      line_position extent
    else
      "file \"" ^ loc_start.pos_fname ^ "\", " ^ (line_position extent)


let file_position ((loc_start, _) as extent) =
  if loc_start.pos_cnum = -1 then
    "<unknown>"
  else
    "File \"" ^ loc_start.pos_fname ^ "\", " ^ (line_position extent)

let input_error mess (loc_start, loc_end) =
  if loc_start.pos_cnum = -1 then
    Printf.printf "Error: %s\n" mess
  else
    Printf.printf "%s:\nError: %s\n"
      (file_position (loc_start, loc_end))
      mess;
  exit 2

let input_warning mess (loc_start, loc_end) =
  if loc_start.pos_cnum = -1 then
    Printf.printf "Warning: \n%s\n" mess
  else
    Printf.printf "%s:\nWarning: %s\n"
      (file_position (loc_start, loc_end))
      mess

let user_error mess =
  print_string mess;
  exit 2

(* Helper functions to lex strings *)
    
let buf = Buffer.create 64
let start_pos = ref Lexing.dummy_pos
let end_pos = ref Lexing.dummy_pos

(* The position of the beginning of a string is just after the opening quotation mark *)
let set_start_pos lexbuf = start_pos := Lexing.lexeme_end_p lexbuf
(* The position of the end of a string is just before the closing quotation mark *)
let set_end_pos lexbuf = end_pos := Lexing.lexeme_start_p lexbuf
    
let clear_buffer () =
  Buffer.reset buf

let get_string () =
  let s = Buffer.contents buf in
  clear_buffer ();
  (s, (!start_pos, !end_pos))

let add_char c =
  Buffer.add_char buf c

let char_backslash = function
    'n' -> '\n'
  | 't' -> '\t'
  | 'b' -> '\b'
  | 'r' -> '\r'
  | c -> c

